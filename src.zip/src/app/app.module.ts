import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule, ReactiveFormsModule} from '@angular/forms'

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { Test1Component } from './test1/test1.component';
import { EmpUpdateComponent } from './emp-update/emp-update.component';
import { NavBarComponent } from './nav-bar/nav-bar.component';
import { HomeComponentComponent } from './home-component/home-component.component';
import { HttpClientModule } from '@angular/common/http';
import { NgxPaginationModule } from 'ngx-pagination';
import { PopUpComponentComponent } from './pop-up-component/pop-up-component.component';
import { EmployeesComponent } from './employees/employees.component';
import { ManagerComponent } from './manager/manager.component';
import { EmpNavComponent } from './employees/emp-nav/emp-nav.component';
import { UpdateskillsComponent } from './employees/updateskills/updateskills.component';
import { HomePageComponent } from './home-page/home-page.component';
import { EmpHomeComponent } from './employees/emp-home/emp-home.component';
import { ManagerNavComponent } from './manager/manager-nav/manager-nav.component';
import { ManagerHomeComponent } from './manager/manager-home/manager-home.component';
import { ManagerAddjobsComponent } from './manager/manager-addjobs/manager-addjobs.component';
import { ManagerAddskillsComponent } from './manager/manager-addskills/manager-addskills.component';
import { ManagerBenchempViewComponent } from './manager/manager-benchemp-view/manager-benchemp-view.component';
import { ManagerOpeningsComponent } from './manager/manager-openings/manager-openings.component';
@NgModule({
  declarations: [
    AppComponent,
    Test1Component,
    EmpUpdateComponent,
    NavBarComponent,
    HomeComponentComponent,
    PopUpComponentComponent,
    EmployeesComponent,
    ManagerComponent,
    EmpNavComponent,
    UpdateskillsComponent,
    HomePageComponent,
    EmpHomeComponent,
    ManagerNavComponent,
    ManagerHomeComponent,
    ManagerAddjobsComponent,
    ManagerAddskillsComponent,
    ManagerBenchempViewComponent,
    ManagerOpeningsComponent,
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule, ReactiveFormsModule,HttpClientModule,
    NgxPaginationModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule {

  
 }
