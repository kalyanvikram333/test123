import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManagerAddskillsComponent } from './manager-addskills.component';

describe('ManagerAddskillsComponent', () => {
  let component: ManagerAddskillsComponent;
  let fixture: ComponentFixture<ManagerAddskillsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManagerAddskillsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManagerAddskillsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
