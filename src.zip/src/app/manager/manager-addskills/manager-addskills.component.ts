import { Component, OnInit } from '@angular/core';
import {FormBuilder,
  FormGroup, Validators}
  from '@angular/forms';
@Component({
  selector: 'app-manager-addskills',
  templateUrl: './manager-addskills.component.html',
  styleUrls: ['./manager-addskills.component.css']
})
export class ManagerAddskillsComponent implements OnInit {

  
name="testname";

submitted = false;

addskillF: FormGroup

constructor(private formBuilder: FormBuilder) { }



//constructor() { }

ngOnInit() {

this.addskillF =
this.formBuilder.group({

additionalSkills: ['',
Validators.required]



});

}

get f() {
return this.addskillF.controls; }

// ngOnInit() {

// }

onSubmit() {

this.submitted =
true;

console.log("onsubmit")

// stop here if form is invalid

if (this.addskillF.invalid) {

return;

}

//alert('SUCCESS!! :-)\n\n' + JSON.stringify(this.addskillF.value))


}





}



