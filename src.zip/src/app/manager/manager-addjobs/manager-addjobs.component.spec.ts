import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManagerAddjobsComponent } from './manager-addjobs.component';

describe('ManagerAddjobsComponent', () => {
  let component: ManagerAddjobsComponent;
  let fixture: ComponentFixture<ManagerAddjobsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManagerAddjobsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManagerAddjobsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
