import { Component, OnInit } from '@angular/core';
import {FormBuilder,FormGroup, Validators}
  from '@angular/forms';
  
  
  
@Component({
  selector: 'app-manager-addjobs',
  templateUrl: './manager-addjobs.component.html',
  styleUrls: ['./manager-addjobs.component.css']
})
export class ManagerAddjobsComponent implements OnInit {

  
submitted = false;

addjobF: FormGroup;

clientname:string;

constructor(private formBuilder: FormBuilder) { }



//constructor() { }

ngOnInit() {

this.addjobF =
this.formBuilder.group({

client: ['',
Validators.required],


technology: ['',Validators.required],

tier: ['',Validators.required],

experience: ['',Validators.required],

clien: ['',Validators.required]



});

}

get f() {
return this.addjobF.controls; }

// ngOnInit() {

// }

onSubmit() {

this.submitted =
true;


// stop here if form is invalid

if (this.addjobF.invalid) {

return;

}

//alert('SUCCESS!! :-)\n\n' + JSON.stringify(this.addjobF.value))



}

}
