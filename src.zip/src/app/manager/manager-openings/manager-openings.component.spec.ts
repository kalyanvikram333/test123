import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManagerOpeningsComponent } from './manager-openings.component';

describe('ManagerOpeningsComponent', () => {
  let component: ManagerOpeningsComponent;
  let fixture: ComponentFixture<ManagerOpeningsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManagerOpeningsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManagerOpeningsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
