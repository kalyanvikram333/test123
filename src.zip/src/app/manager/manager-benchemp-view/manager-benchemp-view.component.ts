import { Component, OnInit } from '@angular/core';
import { HttpClient }
from '@angular/common/http';

import { HttpErrorResponse }
from '@angular/common/http';


@Component({
  selector: 'app-manager-benchemp-view',
  templateUrl: './manager-benchemp-view.component.html',
  styleUrls: ['./manager-benchemp-view.component.css']
})
export class ManagerBenchempViewComponent implements OnInit {

  
constructor (private httpService: HttpClient) { }
  
  arrBirds: string [];
  
  
  p1:Number =
  1;
  
  c: Number =
  8;
  
  // constructor() { }
  
  
  
  ngOnInit () {
  
  this.httpService.get('./assets/test.json').subscribe(
  
  data => {
  
  this.arrBirds =data as string [];   // FILL THE ARRAY WITH DATA.
  
  // console.log(this.arrBirds[1]);
  
  },
  
  (err: HttpErrorResponse)=> {
  
  console.log (err.message);
  
  }
  
  );
  
  }
  
  }
  