import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManagerBenchempViewComponent } from './manager-benchemp-view.component';

describe('ManagerBenchempViewComponent', () => {
  let component: ManagerBenchempViewComponent;
  let fixture: ComponentFixture<ManagerBenchempViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManagerBenchempViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManagerBenchempViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
