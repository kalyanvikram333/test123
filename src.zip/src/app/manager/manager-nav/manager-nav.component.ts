import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manager-nav',
  templateUrl: './manager-nav.component.html',
  styleUrls: ['./manager-nav.component.css']
})
export class ManagerNavComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
