import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
@Component({
  selector: 'app-emp-update',
  templateUrl: './emp-update.component.html',
  styleUrls: ['./emp-update.component.css']
})
export class EmpUpdateComponent implements OnInit {


  name="_NAME_";
  submitted = false;
  updateForm: FormGroup
  constructor(private formBuilder: FormBuilder) { }

  //constructor() { }
  ngOnInit() {
    this.updateForm = this.formBuilder.group({
      primarySkills: ['', Validators.required],
      secondarySkills: ['', Validators.required],
      
  });
  }
  get f() { return this.updateForm.controls; }
  // ngOnInit() {
  // }
  onSubmit() {
    this.submitted = true;

    // stop here if form is invalid
    if (this.updateForm.invalid) {
        return;
    }
    alert('SUCCESS!! :-)\n\n' + JSON.stringify(this.updateForm.value))
  }


}
