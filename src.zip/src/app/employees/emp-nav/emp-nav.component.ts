import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-emp-nav',
  templateUrl: './emp-nav.component.html',
  styleUrls: ['./emp-nav.component.css']
})
export class EmpNavComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
