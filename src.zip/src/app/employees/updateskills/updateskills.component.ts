import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';

@Component({
  selector: 'app-updateskills',
  templateUrl: './updateskills.component.html',
  styleUrls: ['./updateskills.component.css']
})
export class UpdateskillsComponent implements OnInit {

 

  name="_NAME_";
  submitted = false;
  updateForm: FormGroup
  constructor(private formBuilder: FormBuilder) { }

  //constructor() { }
  ngOnInit() {
    this.updateForm = this.formBuilder.group({
      primarySkills: ['', Validators.required],
      secondarySkills: ['', Validators.required],
      
  });
  }
  get f() { return this.updateForm.controls; }
  // ngOnInit() {
  // }
  onSubmit() {
    this.submitted = true;

    // stop here if form is invalid
    if (this.updateForm.invalid) {
        return;
    }
    alert('SUCCESS!! :-)\n\n' + JSON.stringify(this.updateForm.value))
  }


}
