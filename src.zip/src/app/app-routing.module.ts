import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EmpUpdateComponent } from './emp-update/emp-update.component';
import { HomeComponentComponent } from './home-component/home-component.component';
import { PopUpComponentComponent } from './pop-up-component/pop-up-component.component';
import { HomePageComponent } from './home-page/home-page.component';
import { UpdateskillsComponent } from './employees/updateskills/updateskills.component';
import { EmpHomeComponent } from './employees/emp-home/emp-home.component';
import { ManagerAddjobsComponent } from './manager/manager-addjobs/manager-addjobs.component';
import { ManagerAddskillsComponent } from './manager/manager-addskills/manager-addskills.component';
import { ManagerOpeningsComponent } from './manager/manager-openings/manager-openings.component';
import { ManagerBenchempViewComponent } from './manager/manager-benchemp-view/manager-benchemp-view.component';
import { ManagerHomeComponent } from './manager/manager-home/manager-home.component';
import { EmployeesComponent } from './employees/employees.component';

const routes: Routes = [

  // {path: 'updateskill',component: EmpUpdateComponent},
  
  // {path: '',component: HomeComponentComponent},
  // {path: 'jobsavail',component: PopUpComponentComponent}

  {path: 'emp/updateskill',component: UpdateskillsComponent},
  {path: 'emp/home',component: EmployeesComponent},
  // {path: '',component: EmpHomeComponent},
  {path: '',component: HomePageComponent},
  {path: 'manager/home',component: ManagerHomeComponent},

  {path: 'manager/addjob',component: ManagerAddjobsComponent},
  {path: 'manager/addskill',component: ManagerAddskillsComponent},
  {path: 'manager/openings',component: ManagerOpeningsComponent},
  {path: 'manager/bench',component: ManagerBenchempViewComponent},

  // {path: 'emp/addskill',component: }


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule { }
