import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpErrorResponse } from '@angular/common/http';

@Component({
  selector: 'app-pop-up-component',
  templateUrl: './pop-up-component.component.html',
  styleUrls: ['./pop-up-component.component.css']
})
export class PopUpComponentComponent implements OnInit {

  constructor (private httpService:HttpClient) { }
  projects: string [];
  p: Number = 1;
  count: Number = 4;

  ngOnInit () {
    this.httpService.get('./assets/projectList.json').subscribe(
      data => {
        this.projects = data as string [];	 // FILL THE ARRAY WITH DATA.
        //  console.log(this.arrBirds[1]);
      },
      (err: HttpErrorResponse) => {
        console.log (err.message);
      }
    );
  }
}