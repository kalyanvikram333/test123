import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormControl
} from '@angular/forms';
import {

  Validator, AbstractControl, NG_VALIDATORS, ValidatorFn
  
  } from "@angular/forms";
@Component({
  selector: 'app-home-page',
  templateUrl: './home-page.component.html',
  styleUrls: ['./home-page.component.css']
})
export class HomePageComponent implements OnInit {
  name='';
  

registerForm: FormGroup;
    submitted = false;

    constructor(private formBuilder: FormBuilder,private router: Router) { }

    ngOnInit() {

      console.log(this.name);
        this.registerForm = this.formBuilder.group({
            firstName: ['', Validators.required],
            lastName: ['', Validators.required],
            email: ['', [Validators.required, Validators.email]],
            password: ['', [Validators.required, Validators.minLength(6)]],
            confirmPassword: ['', Validators.required]
        }, {
            //validator: MustMatch('password', 'confirmPassword')
        });
    }

    // convenience getter for easy access to form fields
    get f() { return this.registerForm.controls; }

    onSubmit() {
        this.submitted = true;

        // stop here if form is invalid
        if (this.registerForm.invalid) {
            return;
        }

        alert('SUCCESS!! :-)\n\n' + JSON.stringify(this.registerForm.value))
    }
    userName='';
  reg() {

    if (this.userName == 'emp') {
      console.log(this.userName);
                                      
      this.router.navigate(['./employees.component.html']);
    }
  }

  //--------------------------------------------
  loginForm: FormGroup;

loading = false;


returnUrl: string;




}
